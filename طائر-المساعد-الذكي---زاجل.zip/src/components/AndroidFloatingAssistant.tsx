import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CharacterId, BirdEmotion, AppId } from '../types';
import { CharacterRenderer } from './characters/CharacterRenderer';
import { Mic, MicOff, Wand2, X, Move, Sparkles } from 'lucide-react';
import { playChirp, playRobotBeep, playHumanChime } from '../utils/audio';

export interface FlightTarget {
  x: number;
  y: number;
  appId: AppId;
  appName: string;
}

interface AndroidFloatingAssistantProps {
  selectedCharacter: CharacterId;
  emotion: BirdEmotion;
  isSpeaking: boolean;
  beakOpen: boolean;
  isListening: boolean;
  onToggleListening: () => void;
  onOpenCustomizer: () => void;
  onPet: () => void;
  flightTarget: FlightTarget | null;
  onFlightComplete: (appId: AppId) => void;
  snapToEdges?: boolean;
  containerBounds: { width: number; height: number };
  activeApp: AppId | null;
}

export const AndroidFloatingAssistant: React.FC<AndroidFloatingAssistantProps> = ({
  selectedCharacter,
  emotion,
  isSpeaking,
  beakOpen,
  isListening,
  onToggleListening,
  onOpenCustomizer,
  onPet,
  flightTarget,
  onFlightComplete,
  snapToEdges = true,
  containerBounds,
  activeApp,
}) => {
  const overlayRef = useRef<HTMLDivElement>(null);
  const [screenBounds, setScreenBounds] = useState({
    width: containerBounds.width || 360,
    height: containerBounds.height || 780,
  });

  const MASCOT_SIZE = 82;
  const MARGIN_X = 10;
  const MIN_Y = activeApp ? 50 : 65; // Below status bar
  const MAX_Y = screenBounds.height - MASCOT_SIZE - 70; // Above 3-button navigation bar
  const MAX_X = Math.max(MARGIN_X, screenBounds.width - MASCOT_SIZE - MARGIN_X);

  // Initial Floating Position (safely docked on the right inside screen)
  const [position, setPosition] = useState({
    x: 260,
    y: 280,
  });

  const [isDragging, setIsDragging] = useState(false);
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [isPecking, setIsPecking] = useState(false);
  const [accessibilityRipple, setAccessibilityRipple] = useState<{ x: number; y: number } | null>(
    null
  );

  const dragStartRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: 0,
    posY: 0,
  });

  // Measure actual container dimensions to keep mascot strictly bounded
  useEffect(() => {
    const measure = () => {
      if (overlayRef.current) {
        const rect = overlayRef.current.getBoundingClientRect();
        if (rect.width > 50 && rect.height > 100) {
          setScreenBounds({ width: rect.width, height: rect.height });
        }
      }
    };
    measure();
    const timer = setTimeout(measure, 100);
    window.addEventListener('resize', measure);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', measure);
    };
  }, []);

  // Ensure mascot is always strictly clamped within screen bounds
  useEffect(() => {
    setPosition((prev) => {
      const maxX = Math.max(MARGIN_X, screenBounds.width - MASCOT_SIZE - MARGIN_X);
      const maxY = Math.max(MIN_Y, screenBounds.height - MASCOT_SIZE - 70);
      const clampedX = Math.max(MARGIN_X, Math.min(maxX, prev.x));
      const clampedY = Math.max(MIN_Y, Math.min(maxY, prev.y));
      if (clampedX !== prev.x || clampedY !== prev.y) {
        return { x: clampedX, y: clampedY };
      }
      return prev;
    });
  }, [screenBounds, activeApp]);

  // Handle Flight Animation towards target app icon
  useEffect(() => {
    if (flightTarget) {
      setShowQuickMenu(false);
      // Play sound
      if (selectedCharacter === 'smart_robot') playRobotBeep('question');
      else if (selectedCharacter === 'cartoon_human') playHumanChime('question');
      else playChirp('question');

      // Calculate safe target position centered over the app icon
      const targetX = Math.max(
        MARGIN_X,
        Math.min(MAX_X, flightTarget.x - MASCOT_SIZE / 4)
      );
      const targetY = Math.max(
        MIN_Y,
        Math.min(MAX_Y, flightTarget.y - 25)
      );

      // 1. Flight glide to target coordinates
      setPosition({ x: targetX, y: targetY });

      // 2. Pecking dive animation upon arrival
      const timerPeck = setTimeout(() => {
        setIsPecking(true);
        setAccessibilityRipple({ x: targetX + MASCOT_SIZE / 2, y: targetY + MASCOT_SIZE / 2 });

        // Play peck tap click sound
        if (selectedCharacter === 'smart_robot') playRobotBeep('success');
        else if (selectedCharacter === 'cartoon_human') playHumanChime('success');
        else playChirp('cheerful');

        const timerDone = setTimeout(() => {
          setIsPecking(false);
          setAccessibilityRipple(null);
          onFlightComplete(flightTarget.appId);

          // Fly gracefully to docked safe corner of the newly opened app view
          setTimeout(() => {
            setPosition({
              x: Math.max(MARGIN_X, screenBounds.width - MASCOT_SIZE - MARGIN_X),
              y: MIN_Y + 10,
            });
          }, 250);
        }, 550);

        return () => clearTimeout(timerDone);
      }, 650);

      return () => clearTimeout(timerPeck);
    }
  }, [flightTarget, screenBounds.width]);

  // Touch and Mouse Drag Handling
  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: position.x,
      posY: position.y,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - dragStartRef.current.startX;
    const deltaY = e.clientY - dragStartRef.current.startY;

    const newX = dragStartRef.current.posX + deltaX;
    const newY = dragStartRef.current.posY + deltaY;

    // Strict boundary clamping so the bird NEVER leaves the phone screen
    const clampedX = Math.max(MARGIN_X, Math.min(MAX_X, newX));
    const clampedY = Math.max(MIN_Y, Math.min(MAX_Y, newY));

    setPosition({ x: clampedX, y: clampedY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);

    const deltaX = Math.abs(e.clientX - dragStartRef.current.startX);
    const deltaY = Math.abs(e.clientY - dragStartRef.current.startY);

    // If tap without significant movement -> Toggle Quick Menu
    if (deltaX < 6 && deltaY < 6) {
      setShowQuickMenu((prev) => !prev);
      onPet();
      return;
    }

    // Snap smoothly to left or right safe edge of the phone screen
    if (snapToEdges) {
      const midPoint = screenBounds.width / 2;
      const targetEdgeX = position.x < midPoint ? MARGIN_X : MAX_X;
      setPosition((prev) => ({ ...prev, x: targetEdgeX }));
    }
  };

  const currentEmotion: BirdEmotion = isPecking
    ? 'pecking'
    : isDragging
    ? 'flying'
    : flightTarget
    ? 'flying'
    : emotion;

  return (
    <div
      ref={overlayRef}
      className="absolute inset-0 z-40 pointer-events-none overflow-hidden"
      dir="ltr"
      style={{ direction: 'ltr' }}
    >
      {/* Click Ripple Effect for Accessibility Service Peck */}
      {accessibilityRipple && (
        <div
          className="absolute z-50 pointer-events-none -translate-x-1/2 -translate-y-1/2"
          style={{ left: accessibilityRipple.x, top: accessibilityRipple.y }}
        >
          <div className="w-14 h-14 rounded-full bg-cyan-400/50 animate-ping" />
          <div className="absolute inset-0 w-14 h-14 rounded-full border-2 border-white animate-pulse" />
          <div className="absolute -top-7 -right-10 whitespace-nowrap bg-black/90 text-cyan-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-cyan-400/60 shadow-lg" dir="rtl">
            ⚡ نقرة إمكانية الوصول
          </div>
        </div>
      )}

      {/* Floating Assistant Mascot Component */}
      <motion.div
        animate={{
          x: position.x,
          y: position.y,
        }}
        transition={{
          type: isDragging ? 'tween' : 'spring',
          damping: 26,
          stiffness: 300,
        }}
        className="absolute top-0 left-0 pointer-events-auto touch-none cursor-grab active:cursor-grabbing select-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        style={{
          width: MASCOT_SIZE,
          height: MASCOT_SIZE,
        }}
      >
        {/* Android Floating Window Glow Badge */}
        <div className="relative group w-full h-full flex items-center justify-center">
          {/* Subtle Android Overlay Halo */}
          <div className="absolute inset-0 rounded-full bg-cyan-400/20 blur-sm pointer-events-none group-hover:bg-cyan-400/35 transition-colors" />

          {/* Assistant Character Rendered in Compact Floating Size */}
          <div
            className={`transition-transform duration-200 ${
              isPecking
                ? 'scale-115 translate-y-2'
                : isDragging
                ? 'scale-110 -rotate-6'
                : 'scale-100 hover:scale-105'
            }`}
          >
            <CharacterRenderer
              characterId={selectedCharacter}
              emotion={currentEmotion}
              isSpeaking={isSpeaking}
              mouthOpen={beakOpen}
              isListening={isListening}
              size={MASCOT_SIZE}
            />
          </div>

          {/* Mini Drag Handle Pill Indicator */}
          <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded-full bg-black/75 backdrop-blur-xs border border-white/20 text-[8px] text-cyan-300 font-bold flex items-center gap-0.5 pointer-events-none shadow-md">
            <Move className="w-2 h-2" />
            <span>عائم</span>
          </div>

          {/* Quick Radial Floating Actions Menu */}
          <AnimatePresence>
            {showQuickMenu && (
              <motion.div
                initial={{ opacity: 0, scale: 0.6, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.6, y: 10 }}
                dir="rtl"
                className="absolute -top-14 left-1/2 -translate-x-1/2 flex items-center gap-1.5 p-1 rounded-2xl bg-slate-900/95 backdrop-blur-md border border-cyan-400/50 shadow-2xl z-50 whitespace-nowrap"
              >
                {/* Voice button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleListening();
                    setShowQuickMenu(false);
                  }}
                  className={`p-2 rounded-xl text-white active:scale-90 transition-all ${
                    isListening ? 'bg-rose-500 animate-pulse' : 'bg-cyan-600 hover:bg-cyan-500'
                  }`}
                  title="تحدث الآن"
                >
                  {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                </button>

                {/* Customize character */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenCustomizer();
                    setShowQuickMenu(false);
                  }}
                  className="p-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white active:scale-90 transition-all"
                  title="تخصيص الشخصية"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                </button>

                {/* Close menu */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowQuickMenu(false);
                  }}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};
