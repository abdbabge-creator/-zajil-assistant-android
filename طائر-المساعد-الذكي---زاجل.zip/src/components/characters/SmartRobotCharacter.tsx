import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BirdEmotion } from '../../types';
import { playRobotBeep } from '../../utils/audio';

interface SmartRobotCharacterProps {
  emotion: BirdEmotion;
  isSpeaking: boolean;
  mouthOpen: boolean;
  isListening: boolean;
  onPet?: () => void;
  size?: number;
}

export const SmartRobotCharacter: React.FC<SmartRobotCharacterProps> = ({
  emotion,
  isSpeaking,
  mouthOpen,
  isListening,
  onPet,
  size = 180,
}) => {
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 160);
    }, 3500 + Math.random() * 2000);
    return () => clearInterval(blinkInterval);
  }, []);

  const handleClick = () => {
    playRobotBeep('giggle');
    onPet?.();
  };

  const renderVisorEyes = () => {
    if (blink && emotion !== 'surprised') {
      return (
        <g id="robot-blinking-led">
          <line x1="72" y1="90" x2="98" y2="90" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" />
          <line x1="122" y1="90" x2="148" y2="90" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" />
        </g>
      );
    }

    if (emotion === 'happy' || emotion === 'cheering') {
      return (
        <g id="robot-happy-led">
          {/* Cyan Glowing Happy Arches */}
          <path d="M 72 94 Q 85 76 98 94" stroke="#38BDF8" strokeWidth="5" strokeLinecap="round" fill="none" />
          <path d="M 122 94 Q 135 76 148 94" stroke="#38BDF8" strokeWidth="5" strokeLinecap="round" fill="none" />
          {/* Cheerful Pixel Blush */}
          <rect x="62" y="98" width="10" height="4" rx="2" fill="#06B6D4" opacity="0.8" />
          <rect x="148" y="98" width="10" height="4" rx="2" fill="#06B6D4" opacity="0.8" />
        </g>
      );
    }

    if (emotion === 'thinking') {
      return (
        <g id="robot-thinking-led">
          <circle cx="85" cy="88" r="7" stroke="#38BDF8" strokeWidth="3" fill="none" strokeDasharray="3 3" />
          <circle cx="135" cy="88" r="7" stroke="#38BDF8" strokeWidth="3" fill="none" strokeDasharray="3 3" />
        </g>
      );
    }

    // Default High-Tech Glowing Matrix Eyes
    return (
      <g id="robot-normal-led">
        {/* Left LED Eye */}
        <rect x="74" y="78" width="22" height="24" rx="7" fill="#0284C7" />
        <rect x="76" y="80" width="18" height="20" rx="5" fill="#38BDF8" />
        <circle cx="82" cy="86" r="3.5" fill="#FFFFFF" />

        {/* Right LED Eye */}
        <rect x="124" y="78" width="22" height="24" rx="7" fill="#0284C7" />
        <rect x="126" y="80" width="18" height="20" rx="5" fill="#38BDF8" />
        <circle cx="132" cy="86" r="3.5" fill="#FFFFFF" />
      </g>
    );
  };

  return (
    <div
      className="relative flex flex-col items-center justify-center cursor-pointer select-none"
      style={{ width: size, height: size }}
      onClick={handleClick}
    >
      {/* Listening Radar Grid */}
      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: [1, 1.4, 1], opacity: [0.7, 0.2, 0.7] }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute inset-0 rounded-full border-2 border-cyan-400/50 bg-radial from-cyan-500/20 to-transparent blur-xs pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Thinking Binary Emoticon */}
      <AnimatePresence>
        {emotion === 'thinking' && (
          <motion.div
            initial={{ y: 10, opacity: 0, scale: 0.5 }}
            animate={{ y: -30, opacity: 1, scale: 1 }}
            exit={{ y: -40, opacity: 0 }}
            className="absolute -top-3 right-6 bg-cyan-600 text-white font-mono text-xs px-2.5 py-1 rounded-full shadow-lg border-2 border-white flex items-center gap-1 z-20 pointer-events-none"
          >
            <span className="animate-spin">⚙️</span>
            <span>معالجة...</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Robot SVG */}
      <motion.div
        animate={
          isSpeaking
            ? { y: [0, -5, 0], transition: { duration: 0.35, repeat: Infinity } }
            : isListening
            ? { rotate: [-2, 2, -2], y: [-2, 2, -2], transition: { duration: 1.8, repeat: Infinity } }
            : emotion === 'cheering'
            ? { y: [0, -16, 0], rotate: [0, 15, -15, 0], scale: [1, 1.08, 1], transition: { duration: 0.5, repeat: 3 } }
            : { y: [0, -5, 0], transition: { duration: 2.5, repeat: Infinity, ease: 'easeInOut' } }
        }
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="w-full h-full relative"
      >
        <svg viewBox="0 0 220 220" className="w-full h-full drop-shadow-[0_12px_24px_rgba(6,182,212,0.4)]" fill="none">
          <defs>
            <linearGradient id="robotBodyGrad" x1="40" y1="30" x2="180" y2="190" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="60%" stopColor="#E2E8F0" />
              <stop offset="100%" stopColor="#94A3B8" />
            </linearGradient>

            <linearGradient id="visorGrad" x1="60" y1="60" x2="160" y2="140" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#0F172A" />
              <stop offset="100%" stopColor="#020617" />
            </linearGradient>

            <linearGradient id="glowCyan" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#38BDF8" />
              <stop offset="100%" stopColor="#06B6D4" />
            </linearGradient>
          </defs>

          {/* Plasma Thruster Glow Shadow */}
          <ellipse cx="110" cy="195" rx="35" ry="8" fill="#38BDF8" opacity={isSpeaking ? 0.8 : 0.4} />

          {/* Antenna */}
          <g id="antenna">
            <line x1="110" y1="45" x2="110" y2="18" stroke="#64748B" strokeWidth="4" strokeLinecap="round" />
            <circle cx="110" cy="14" r="7" fill="url(#glowCyan)" />
            {isListening && <circle cx="110" cy="14" r="12" stroke="#38BDF8" strokeWidth="1.5" className="animate-ping" />}
          </g>

          {/* Floating Magnetic Hand Left */}
          <motion.g
            animate={isSpeaking ? { y: [0, -4, 0] } : { y: [0, 3, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          >
            <rect x="24" y="112" width="18" height="26" rx="9" fill="url(#robotBodyGrad)" stroke="#64748B" strokeWidth="2" />
            <circle cx="33" cy="125" r="3" fill="#38BDF8" />
          </motion.g>

          {/* Floating Magnetic Hand Right */}
          <motion.g
            animate={isSpeaking ? { y: [0, -4, 0] } : { y: [0, -3, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          >
            <rect x="178" y="112" width="18" height="26" rx="9" fill="url(#robotBodyGrad)" stroke="#64748B" strokeWidth="2" />
            <circle cx="187" cy="125" r="3" fill="#38BDF8" />
          </motion.g>

          {/* Spherical Main Body */}
          <rect
            x="48"
            y="42"
            width="124"
            height="135"
            rx="55"
            fill="url(#robotBodyGrad)"
            stroke="#64748B"
            strokeWidth="3.5"
          />

          {/* Ear Sensor Pods */}
          <rect x="40" y="85" width="10" height="28" rx="5" fill="#38BDF8" />
          <rect x="170" y="85" width="10" height="28" rx="5" fill="#38BDF8" />

          {/* Dark Glass Visor Screen */}
          <rect
            x="58"
            y="65"
            width="104"
            height="72"
            rx="24"
            fill="url(#visorGrad)"
            stroke="#334155"
            strokeWidth="2.5"
          />

          {/* Visor Glint Reflection */}
          <path d="M 64 74 Q 110 68 156 74" stroke="#FFFFFF" strokeWidth="1.5" opacity="0.3" strokeLinecap="round" />

          {/* LED Eyes */}
          {renderVisorEyes()}

          {/* Digital LED Mouth (Changes height / waves with speech) */}
          <g id="robot-led-mouth">
            <motion.rect
              animate={{
                height: mouthOpen || isSpeaking ? [4, 12, 6, 14, 4] : 4,
                y: mouthOpen || isSpeaking ? [118, 114, 117, 113, 118] : 118,
              }}
              transition={{ duration: 0.25, repeat: isSpeaking ? Infinity : 0 }}
              x="92"
              width="36"
              rx="2"
              fill="#38BDF8"
            />
          </g>

          {/* Chest Core Indicator Light */}
          <circle cx="110" cy="155" r="7" fill="#0F172A" />
          <circle cx="110" cy="155" r="4.5" fill="#38BDF8" className={isSpeaking ? 'animate-pulse' : ''} />
        </svg>
      </motion.div>
    </div>
  );
};
