import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BirdEmotion } from '../../types';
import { playHumanChime } from '../../utils/audio';

interface CartoonHumanCharacterProps {
  emotion: BirdEmotion;
  isSpeaking: boolean;
  mouthOpen: boolean;
  isListening: boolean;
  onPet?: () => void;
  size?: number;
}

export const CartoonHumanCharacter: React.FC<CartoonHumanCharacterProps> = ({
  emotion,
  isSpeaking,
  mouthOpen,
  isListening,
  onPet,
  size = 180,
}) => {
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 180);
    }, 3000 + Math.random() * 2000);
    return () => clearInterval(blinkInterval);
  }, []);

  const handleClick = () => {
    playHumanChime('giggle');
    onPet?.();
  };

  const renderEyes = () => {
    if (blink && emotion !== 'surprised') {
      return (
        <g id="human-blinking-eyes">
          <path d="M 72 88 Q 85 91 98 88" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d="M 122 88 Q 135 91 148 88" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
        </g>
      );
    }

    if (emotion === 'happy' || emotion === 'cheering') {
      return (
        <g id="human-happy-eyes">
          <path d="M 72 90 Q 85 75 98 90" stroke="#0F172A" strokeWidth="5" strokeLinecap="round" fill="none" />
          <path d="M 122 90 Q 135 75 148 90" stroke="#0F172A" strokeWidth="5" strokeLinecap="round" fill="none" />
          {/* Sweet Cheerful Blush */}
          <ellipse cx="66" cy="102" rx="9" ry="5" fill="#FB7185" opacity="0.6" />
          <ellipse cx="154" cy="102" rx="9" ry="5" fill="#FB7185" opacity="0.6" />
        </g>
      );
    }

    // Default Big Glossy Anime Cartoon Eyes
    return (
      <g id="human-normal-eyes">
        {/* Left Eye */}
        <ellipse cx="85" cy="88" rx="14" ry="18" fill="#FFFFFF" stroke="#1E293B" strokeWidth="3" />
        <ellipse cx={isListening ? 87 : 85} cy="88" rx="9" ry="12" fill="#1E1B4B" />
        <ellipse cx={86} cy="89" rx="6" ry="8" fill="#6366F1" />
        <circle cx={83} cy="84" r="4.5" fill="#FFFFFF" />
        <circle cx={88} cy="91" r="2" fill="#FFFFFF" />

        {/* Right Eye */}
        <ellipse cx="135" cy="88" rx="14" ry="18" fill="#FFFFFF" stroke="#1E293B" strokeWidth="3" />
        <ellipse cx={isListening ? 137 : 135} cy="88" rx="9" ry="12" fill="#1E1B4B" />
        <ellipse cx={136} cy="89" rx="6" ry="8" fill="#6366F1" />
        <circle cx={133} cy="84" r="4.5" fill="#FFFFFF" />
        <circle cx={138} cy="91" r="2" fill="#FFFFFF" />

        {/* Eyebrows */}
        <path
          d={emotion === 'thinking' ? 'M 72 70 Q 85 64 96 72' : 'M 72 72 Q 85 68 96 72'}
          stroke="#334155"
          strokeWidth="3.5"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d={emotion === 'thinking' ? 'M 124 72 Q 135 64 148 70' : 'M 124 72 Q 135 68 148 72'}
          stroke="#334155"
          strokeWidth="3.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Cheerful Blush */}
        <ellipse cx="68" cy="100" rx="8" ry="4.5" fill="#FB7185" opacity="0.55" />
        <ellipse cx="152" cy="100" rx="8" ry="4.5" fill="#FB7185" opacity="0.55" />
      </g>
    );
  };

  return (
    <div
      className="relative flex flex-col items-center justify-center cursor-pointer select-none"
      style={{ width: size, height: size }}
      onClick={handleClick}
    >
      {/* Listening Aura */}
      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: [1, 1.35, 1], opacity: [0.6, 0.2, 0.6] }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute inset-0 rounded-full bg-radial from-amber-400/30 via-orange-400/15 to-transparent blur-md pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Thinking Lightbulb */}
      <AnimatePresence>
        {emotion === 'thinking' && (
          <motion.div
            initial={{ y: 10, opacity: 0, scale: 0.5 }}
            animate={{ y: -30, opacity: 1, scale: 1 }}
            exit={{ y: -40, opacity: 0 }}
            className="absolute -top-3 right-6 bg-amber-400 text-slate-900 font-bold text-xs px-2.5 py-1 rounded-full shadow-lg border-2 border-white flex items-center gap-1 z-20 pointer-events-none"
          >
            <span>💡</span>
            <span>أفكر...</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SVG Human Figure */}
      <motion.div
        animate={
          isSpeaking
            ? { y: [0, -6, 0], rotate: [0, 1.5, -1.5, 0], transition: { duration: 0.45, repeat: Infinity } }
            : isListening
            ? { rotate: [-2, 2, -2], y: [-2, 2, -2], transition: { duration: 1.8, repeat: Infinity } }
            : emotion === 'cheering'
            ? { y: [0, -18, 0], rotate: [0, 8, -8, 0], scale: [1, 1.08, 1], transition: { duration: 0.5, repeat: 3 } }
            : { y: [0, -4, 0], transition: { duration: 2.8, repeat: Infinity, ease: 'easeInOut' } }
        }
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="w-full h-full relative"
      >
        <svg viewBox="0 0 220 220" className="w-full h-full drop-shadow-[0_12px_24px_rgba(245,158,11,0.35)]" fill="none">
          <defs>
            <linearGradient id="skinGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FED7AA" />
              <stop offset="100%" stopColor="#FDBA74" />
            </linearGradient>

            <linearGradient id="hairGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#334155" />
              <stop offset="100%" stopColor="#1E293B" />
            </linearGradient>

            <linearGradient id="hoodieGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#F59E0B" />
              <stop offset="100%" stopColor="#D97706" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="110" cy="204" rx="55" ry="8" fill="#0F172A" opacity="0.3" />

          {/* Torso / Hoodie Shoulders */}
          <path
            d="M 52 185 C 52 155 75 142 110 142 C 145 142 168 155 168 185 C 168 198 150 202 110 202 C 70 202 52 198 52 185 Z"
            fill="url(#hoodieGrad)"
            stroke="#B45309"
            strokeWidth="3"
          />
          {/* Hoodie Collar Strings */}
          <path d="M 98 152 L 96 172 M 122 152 L 124 172" stroke="#FEF3C7" strokeWidth="3" strokeLinecap="round" />

          {/* Neck */}
          <rect x="96" y="128" width="28" height="24" rx="8" fill="url(#skinGrad)" />

          {/* Head Shape */}
          <ellipse cx="110" cy="95" rx="54" ry="50" fill="url(#skinGrad)" stroke="#FB923C" strokeWidth="2.5" />

          {/* Ears */}
          <ellipse cx="54" cy="95" rx="9" ry="12" fill="url(#skinGrad)" stroke="#FB923C" strokeWidth="2" />
          <ellipse cx="166" cy="95" rx="9" ry="12" fill="url(#skinGrad)" stroke="#FB923C" strokeWidth="2" />

          {/* Stylish Hair Behind */}
          <path
            d="M 54 85 C 54 40 75 25 110 25 C 145 25 166 40 166 85 C 166 115 158 135 158 135 C 158 135 145 130 140 115 C 130 125 110 125 100 115 C 95 130 82 135 82 135 C 82 135 54 115 54 85 Z"
            fill="url(#hairGrad)"
          />

          {/* Hair Front Bangs */}
          <path
            d="M 64 62 C 85 45 135 45 156 62 C 148 78 128 72 120 80 C 112 68 95 76 86 70 C 76 78 68 72 64 62 Z"
            fill="url(#hairGrad)"
          />

          {/* Headset Arc & Earcups */}
          <path d="M 52 92 C 50 48 80 26 110 26 C 140 26 170 48 168 92" stroke="#38BDF8" strokeWidth="5" fill="none" strokeLinecap="round" />
          <rect x="44" y="80" width="14" height="28" rx="6" fill="#0284C7" stroke="#38BDF8" strokeWidth="2" />
          <rect x="162" y="80" width="14" height="28" rx="6" fill="#0284C7" stroke="#38BDF8" strokeWidth="2" />
          {/* Headset Microphone Boom */}
          <path d="M 50 102 Q 54 122 75 120" stroke="#38BDF8" strokeWidth="3" fill="none" strokeLinecap="round" />
          <circle cx="76" cy="120" r="4" fill="#38BDF8" />

          {/* Eyes */}
          {renderEyes()}

          {/* Cute Nose */}
          <path d="M 110 99 L 108 105 L 112 105" stroke="#F97316" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />

          {/* Mouth with Synchronized Lip-Sync */}
          <g id="human-mouth">
            <motion.path
              animate={{
                d: mouthOpen || isSpeaking
                  ? 'M 96 115 Q 110 132 124 115 C 118 126 102 126 96 115 Z'
                  : 'M 99 116 Q 110 124 121 116',
              }}
              transition={{ duration: 0.1 }}
              fill={mouthOpen || isSpeaking ? '#BE123C' : 'none'}
              stroke="#881337"
              strokeWidth="3"
              strokeLinecap="round"
            />
            {(mouthOpen || isSpeaking) && (
              <path d="M 103 124 Q 110 128 117 124" stroke="#FDA4AF" strokeWidth="2" fill="none" strokeLinecap="round" />
            )}
          </g>
        </svg>
      </motion.div>
    </div>
  );
};
