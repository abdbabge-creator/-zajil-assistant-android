import React from 'react';
import { CharacterId, BirdEmotion } from '../../types';
import { CartoonBird } from '../CartoonBird';
import { FemaleBirdCharacter } from './FemaleBirdCharacter';
import { SmartRobotCharacter } from './SmartRobotCharacter';
import { CartoonHumanCharacter } from './CartoonHumanCharacter';

interface CharacterRendererProps {
  characterId: CharacterId;
  emotion: BirdEmotion;
  isSpeaking: boolean;
  mouthOpen: boolean;
  isListening: boolean;
  onPet?: () => void;
  size?: number;
}

export const CharacterRenderer: React.FC<CharacterRendererProps> = ({
  characterId,
  emotion,
  isSpeaking,
  mouthOpen,
  isListening,
  onPet,
  size = 190,
}) => {
  switch (characterId) {
    case 'female_bird':
      return (
        <FemaleBirdCharacter
          emotion={emotion}
          isSpeaking={isSpeaking}
          mouthOpen={mouthOpen}
          isListening={isListening}
          onPet={onPet}
          size={size}
        />
      );

    case 'smart_robot':
      return (
        <SmartRobotCharacter
          emotion={emotion}
          isSpeaking={isSpeaking}
          mouthOpen={mouthOpen}
          isListening={isListening}
          onPet={onPet}
          size={size}
        />
      );

    case 'cartoon_human':
      return (
        <CartoonHumanCharacter
          emotion={emotion}
          isSpeaking={isSpeaking}
          mouthOpen={mouthOpen}
          isListening={isListening}
          onPet={onPet}
          size={size}
        />
      );

    case 'male_bird':
    default:
      return (
        <CartoonBird
          emotion={emotion}
          isSpeaking={isSpeaking}
          beakOpen={mouthOpen}
          isListening={isListening}
          onPet={onPet}
          size={size}
        />
      );
  }
};
