import React, { useState } from 'react';
import { Image as ImageIcon, Trash2, X, Download } from 'lucide-react';

interface GalleryAppProps {
  photos: string[];
  onDeletePhoto?: (index: number) => void;
}

export const GalleryApp: React.FC<GalleryAppProps> = ({ photos, onDeletePhoto }) => {
  const [activePhoto, setActivePhoto] = useState<string | null>(null);

  // Default gallery sample photos if empty
  const defaultBirdWallpapers = [
    'https://images.unsplash.com/photo-1549608276-5786777e6587?w=600&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1552728089-57bdde30beb3?w=600&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1444464666168-49d633b86797?w=600&auto=format&fit=crop&q=80',
  ];

  const allPhotos = photos.length > 0 ? photos : defaultBirdWallpapers;

  return (
    <div className="h-full bg-slate-950 text-white flex flex-col p-5 select-none">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
          <ImageIcon className="w-4 h-4" />
        </div>
        <div>
          <h2 className="text-xl font-bold">معرض الصور</h2>
          <p className="text-xs text-slate-400">{allPhotos.length} صورة</p>
        </div>
      </div>

      {/* Grid of Photos */}
      <div className="flex-1 overflow-y-auto grid grid-cols-2 gap-3 pr-1">
        {allPhotos.map((url, idx) => (
          <div
            key={idx}
            onClick={() => setActivePhoto(url)}
            className="aspect-square rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 cursor-pointer relative group hover:scale-102 active:scale-95 transition-all shadow-md"
          >
            <img src={url} alt={`صورة ${idx + 1}`} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="text-xs font-bold text-white bg-black/60 px-2 py-1 rounded-md">
                عرض
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Full Photo Modal */}
      {activePhoto && (
        <div className="absolute inset-0 z-50 bg-black/95 flex flex-col justify-between p-4 backdrop-blur-md">
          <div className="flex justify-between items-center text-white">
            <span className="text-sm font-semibold">معاينة الصورة</span>
            <button
              onClick={() => setActivePhoto(null)}
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 flex items-center justify-center p-2">
            <img
              src={activePhoto}
              alt="معاينة"
              className="max-w-full max-h-[70vh] rounded-2xl object-contain shadow-2xl"
            />
          </div>

          <div className="flex justify-center gap-4 py-2">
            <a
              href={activePhoto}
              download="zajil_photo.jpg"
              className="px-4 py-2 rounded-xl bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 hover:bg-white/30"
            >
              <Download className="w-4 h-4" />
              <span>تحميل</span>
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
