import React, { useState, useEffect } from 'react';
import { Delete } from 'lucide-react';

interface CalculatorAppProps {
  initialExpression?: string;
  initialResult?: string;
}

export const CalculatorApp: React.FC<CalculatorAppProps> = ({
  initialExpression,
  initialResult,
}) => {
  const [display, setDisplay] = useState('0');
  const [prevValue, setPrevValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewNumber, setWaitingForNewNumber] = useState(false);
  const [history, setHistory] = useState<string>('');

  useEffect(() => {
    if (initialResult) {
      setDisplay(initialResult);
      if (initialExpression) {
        setHistory(initialExpression + ' =');
      }
    }
  }, [initialExpression, initialResult]);

  const handleDigit = (digit: string) => {
    if (waitingForNewNumber) {
      setDisplay(digit);
      setWaitingForNewNumber(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const handleDecimal = () => {
    if (waitingForNewNumber) {
      setDisplay('0.');
      setWaitingForNewNumber(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setPrevValue(null);
    setOperation(null);
    setWaitingForNewNumber(false);
    setHistory('');
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  const handleOperation = (op: string) => {
    const current = parseFloat(display);

    if (prevValue === null) {
      setPrevValue(current);
      setHistory(`${current} ${op}`);
    } else if (operation) {
      const result = executeCalc(prevValue, current, operation);
      setPrevValue(result);
      setDisplay(String(result));
      setHistory(`${result} ${op}`);
    }

    setOperation(op);
    setWaitingForNewNumber(true);
  };

  const executeCalc = (a: number, b: number, op: string): number => {
    switch (op) {
      case '+':
        return a + b;
      case '−':
        return a - b;
      case '×':
        return a * b;
      case '÷':
        return b !== 0 ? a / b : 0;
      default:
        return b;
    }
  };

  const handleEquals = () => {
    const current = parseFloat(display);
    if (prevValue !== null && operation) {
      const result = executeCalc(prevValue, current, operation);
      setHistory(`${prevValue} ${operation} ${current} =`);
      setDisplay(String(result));
      setPrevValue(null);
      setOperation(null);
      setWaitingForNewNumber(true);
    }
  };

  const buttons = [
    { label: 'C', action: handleClear, color: 'bg-slate-700 text-rose-300' },
    { label: '⌫', action: handleBackspace, color: 'bg-slate-700 text-slate-200' },
    { label: '%', action: () => setDisplay(String(parseFloat(display) / 100)), color: 'bg-slate-700 text-cyan-300' },
    { label: '÷', action: () => handleOperation('÷'), color: 'bg-amber-600 text-white font-bold' },

    { label: '7', action: () => handleDigit('7'), color: 'bg-slate-800 text-white' },
    { label: '8', action: () => handleDigit('8'), color: 'bg-slate-800 text-white' },
    { label: '9', action: () => handleDigit('9'), color: 'bg-slate-800 text-white' },
    { label: '×', action: () => handleOperation('×'), color: 'bg-amber-600 text-white font-bold' },

    { label: '4', action: () => handleDigit('4'), color: 'bg-slate-800 text-white' },
    { label: '5', action: () => handleDigit('5'), color: 'bg-slate-800 text-white' },
    { label: '6', action: () => handleDigit('6'), color: 'bg-slate-800 text-white' },
    { label: '−', action: () => handleOperation('−'), color: 'bg-amber-600 text-white font-bold' },

    { label: '1', action: () => handleDigit('1'), color: 'bg-slate-800 text-white' },
    { label: '2', action: () => handleDigit('2'), color: 'bg-slate-800 text-white' },
    { label: '3', action: () => handleDigit('3'), color: 'bg-slate-800 text-white' },
    { label: '+', action: () => handleOperation('+'), color: 'bg-amber-600 text-white font-bold' },

    { label: '0', action: () => handleDigit('0'), color: 'col-span-2 bg-slate-800 text-white' },
    { label: '.', action: handleDecimal, color: 'bg-slate-800 text-white' },
    { label: '=', action: handleEquals, color: 'bg-emerald-600 text-white font-bold' },
  ];

  return (
    <div className="h-full flex flex-col justify-end p-5 bg-slate-950 select-none" dir="ltr">
      {/* History and Display Screen */}
      <div className="mb-6 text-right px-2">
        <div className="text-slate-400 text-sm h-6 overflow-hidden tracking-wider font-mono">
          {history}
        </div>
        <div className="text-white text-5xl font-light tracking-tight truncate mt-1 font-mono">
          {display}
        </div>
      </div>

      {/* Button Grid */}
      <div className="grid grid-cols-4 gap-3">
        {buttons.map((btn, index) => (
          <button
            key={index}
            onClick={btn.action}
            className={`h-16 rounded-2xl text-2xl font-medium active:scale-90 transition-transform shadow-md flex items-center justify-center ${btn.color}`}
          >
            {btn.label === '⌫' ? <Delete className="w-6 h-6" /> : btn.label}
          </button>
        ))}
      </div>
    </div>
  );
};
