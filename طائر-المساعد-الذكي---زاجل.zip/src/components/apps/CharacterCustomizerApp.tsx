import React, { useState } from 'react';
import { User, Volume2, Sparkles, Check, Play, RefreshCw, Wand2 } from 'lucide-react';
import { CharacterId, VoiceGender, BirdEmotion } from '../../types';
import { CHARACTER_PROFILES } from '../characters/characterProfiles';
import { CharacterRenderer } from '../characters/CharacterRenderer';
import { playChirp, playRobotBeep, playHumanChime } from '../../utils/audio';

interface CharacterCustomizerAppProps {
  selectedCharacter: CharacterId;
  onSelectCharacter: (id: CharacterId) => void;
  voiceGender: VoiceGender;
  onSelectVoiceGender: (gender: VoiceGender) => void;
  voicePitch: number;
  setVoicePitch: (p: number) => void;
  voiceRate: number;
  setVoiceRate: (r: number) => void;
  onTestVoice: (greeting: string, gender: VoiceGender) => void;
  isSpeaking: boolean;
  mouthOpen: boolean;
}

export const CharacterCustomizerApp: React.FC<CharacterCustomizerAppProps> = ({
  selectedCharacter,
  onSelectCharacter,
  voiceGender,
  onSelectVoiceGender,
  voicePitch,
  setVoicePitch,
  voiceRate,
  setVoiceRate,
  onTestVoice,
  isSpeaking,
  mouthOpen,
}) => {
  const [previewEmotion, setPreviewEmotion] = useState<BirdEmotion>('idle');
  const [isListeningTest, setIsListeningTest] = useState(false);

  const currentProfile = CHARACTER_PROFILES[selectedCharacter] || CHARACTER_PROFILES.male_bird;

  const handleCharacterChange = (id: CharacterId) => {
    onSelectCharacter(id);
    const profile = CHARACTER_PROFILES[id];
    if (profile) {
      onSelectVoiceGender(profile.gender);
      setVoicePitch(profile.defaultPitch);
      setVoiceRate(profile.defaultRate);

      if (id === 'smart_robot') playRobotBeep('success');
      else if (id === 'cartoon_human') playHumanChime('success');
      else playChirp('success');
    }
  };

  const handleEmotionTest = (emotion: BirdEmotion) => {
    setPreviewEmotion(emotion);
    setIsListeningTest(emotion === 'listening');
    if (emotion !== 'idle') {
      setTimeout(() => {
        setPreviewEmotion('idle');
        setIsListeningTest(false);
      }, 3000);
    }
  };

  const handlePlayGreeting = () => {
    onTestVoice(currentProfile.greeting, voiceGender);
  };

  return (
    <div className="h-full bg-slate-950 text-white flex flex-col p-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center gap-2.5 mb-3 pb-2 border-b border-slate-800">
        <div className="w-8 h-8 rounded-xl bg-linear-to-tr from-cyan-500 to-indigo-600 text-white flex items-center justify-center shadow-md">
          <Wand2 className="w-4 h-4" />
        </div>
        <div>
          <h2 className="text-lg font-bold">تخصيص شخصية المساعد</h2>
          <p className="text-[11px] text-slate-400">اختر مظهر وصوت المساعد المناسب لك</p>
        </div>
      </div>

      {/* Live Interactive Character Preview Canvas */}
      <div className="relative rounded-3xl bg-linear-to-b from-slate-900 to-slate-950 border border-slate-800/80 p-3 flex flex-col items-center justify-center shadow-inner mb-4 overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute inset-0 bg-radial from-cyan-500/10 via-transparent to-transparent pointer-events-none" />

        <div className="py-1">
          <CharacterRenderer
            characterId={selectedCharacter}
            emotion={previewEmotion}
            isSpeaking={isSpeaking}
            mouthOpen={mouthOpen}
            isListening={isListeningTest}
            size={160}
          />
        </div>

        {/* Character Title Badge */}
        <div className="mt-1 text-center">
          <div className="text-base font-bold text-white flex items-center justify-center gap-1.5">
            <span>{currentProfile.name}</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 border border-slate-700">
              {currentProfile.title}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5 max-w-xs">{currentProfile.description}</p>
        </div>

        {/* Quick Emotion Movement Testing Row */}
        <div className="mt-3 w-full">
          <div className="text-[10px] text-slate-500 mb-1 font-semibold text-center">
            اختبر حركات وتعبيرات الشخصية:
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { id: 'idle' as BirdEmotion, label: 'انتظار 💤' },
              { id: 'listening' as BirdEmotion, label: 'استماع 👂' },
              { id: 'thinking' as BirdEmotion, label: 'تفكير 💭' },
              { id: 'cheering' as BirdEmotion, label: 'فرح 🎉' },
            ].map((em) => (
              <button
                key={em.id}
                onClick={() => handleEmotionTest(em.id)}
                className={`py-1.5 px-1 rounded-xl text-[10px] font-bold border transition-all active:scale-95 ${
                  previewEmotion === em.id
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
              >
                {em.label}
              </button>
            ))}
          </div>
        </div>

        {/* Listen to Voice Sample Button */}
        <button
          onClick={handlePlayGreeting}
          className="mt-3 px-4 py-2 rounded-full bg-linear-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 hover:brightness-110 active:scale-95 transition-all flex items-center gap-2"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>استمع لصوت الشخصية الآن 🔊</span>
        </button>
      </div>

      {/* 4 Characters Selection Grid */}
      <div className="mb-4">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
          اختر من بين 4 شخصيات:
        </h3>
        <div className="grid grid-cols-2 gap-2.5">
          {Object.values(CHARACTER_PROFILES).map((char) => {
            const isSelected = selectedCharacter === char.id;
            return (
              <div
                key={char.id}
                onClick={() => handleCharacterChange(char.id as CharacterId)}
                className={`p-3 rounded-2xl border cursor-pointer active:scale-98 transition-all flex flex-col justify-between relative ${
                  isSelected
                    ? 'bg-slate-900 border-cyan-400 ring-2 ring-cyan-400/30 shadow-lg shadow-cyan-500/10'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                {isSelected && (
                  <div className="absolute top-2 left-2 w-5 h-5 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center font-bold">
                    <Check className="w-3 h-3" />
                  </div>
                )}
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-10 h-10 rounded-xl ${char.avatarBg} text-white flex items-center justify-center text-lg shadow-md`}
                  >
                    {char.id === 'male_bird'
                      ? '🐦'
                      : char.id === 'female_bird'
                      ? '🌸'
                      : char.id === 'smart_robot'
                      ? '🤖'
                      : '🧑'}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">{char.name}</div>
                    <div className="text-[10px] text-slate-400">{char.title}</div>
                  </div>
                </div>
                <div className="mt-2 text-[10px] text-slate-400 line-clamp-1">{char.description}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Voice Gender Selection (Male / Female Arabic Voice) */}
      <div className="mb-4">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
          نوع الصوت العربي:
        </h3>
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => onSelectVoiceGender('male')}
            className={`p-3 rounded-2xl border flex items-center justify-center gap-2 transition-all active:scale-95 ${
              voiceGender === 'male'
                ? 'bg-blue-600/20 border-blue-400 text-blue-300 font-bold shadow-md'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <span className="text-base">👨</span>
            <span className="text-xs">صوت ذكر عربي</span>
          </button>
          <button
            onClick={() => onSelectVoiceGender('female')}
            className={`p-3 rounded-2xl border flex items-center justify-center gap-2 transition-all active:scale-95 ${
              voiceGender === 'female'
                ? 'bg-pink-600/20 border-pink-400 text-pink-300 font-bold shadow-md'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <span className="text-base">👩</span>
            <span className="text-xs">صوت أنثى عربي</span>
          </button>
        </div>
      </div>

      {/* Voice Pitch and Speed Fine-tuning */}
      <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 mb-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-300">تعديل نبرة الصوت وسرعته</span>
          <button
            onClick={() => {
              setVoicePitch(currentProfile.defaultPitch);
              setVoiceRate(currentProfile.defaultRate);
            }}
            className="text-[10px] text-cyan-400 hover:underline flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>إعادة ضبط للافتراضي</span>
          </button>
        </div>

        <div>
          <div className="flex justify-between text-[11px] mb-1">
            <span className="text-slate-400">طبقة الصوت (Pitch)</span>
            <span className="text-cyan-400 font-mono">{voicePitch.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.75"
            max="1.5"
            step="0.05"
            value={voicePitch}
            onChange={(e) => setVoicePitch(parseFloat(e.target.value))}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between text-[11px] mb-1">
            <span className="text-slate-400">سرعة الكلام (Speed)</span>
            <span className="text-cyan-400 font-mono">{voiceRate.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.8"
            max="1.3"
            step="0.05"
            value={voiceRate}
            onChange={(e) => setVoiceRate(parseFloat(e.target.value))}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>
      </div>

      <div className="text-center py-1">
        <span className="text-[10px] text-emerald-400 flex items-center justify-center gap-1">
          <Check className="w-3 h-3" />
          <span>يتم حفظ جميع التفضيلات تلقائياً في ذاكرة هاتفك</span>
        </span>
      </div>
    </div>
  );
};
