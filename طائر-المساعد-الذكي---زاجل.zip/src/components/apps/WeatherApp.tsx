import React, { useState } from 'react';
import { Sun, Cloud, CloudRain, CloudSun, Wind, Droplets, MapPin, Search } from 'lucide-react';

interface WeatherAppProps {
  initialCity?: string;
  hasLocationPermission: boolean;
  onRequestLocationPermission: () => Promise<boolean>;
}

interface CityWeather {
  city: string;
  temp: number;
  condition: string;
  high: number;
  low: number;
  humidity: number;
  wind: number;
  type: 'sunny' | 'cloudy' | 'rainy' | 'partly';
}

const CITIES_DATA: Record<string, CityWeather> = {
  الرياض: { city: 'الرياض', temp: 31, condition: 'مشمس ودافئ', high: 33, low: 20, humidity: 18, wind: 14, type: 'sunny' },
  دبي: { city: 'دبي', temp: 29, condition: 'صافٍ ومعتدل', high: 30, low: 22, humidity: 45, wind: 12, type: 'sunny' },
  القاهرة: { city: 'القاهرة', temp: 24, condition: 'غائم جزئياً', high: 26, low: 16, humidity: 55, wind: 18, type: 'partly' },
  'مكة المكرمة': { city: 'مكة المكرمة', temp: 34, condition: 'حار وصافٍ', high: 36, low: 25, humidity: 22, wind: 10, type: 'sunny' },
  جدة: { city: 'جدة', temp: 30, condition: 'رطب ومعتدل', high: 32, low: 24, humidity: 60, wind: 15, type: 'partly' },
  الكويت: { city: 'الكويت', temp: 28, condition: 'مشمس ولطيف', high: 30, low: 19, humidity: 25, wind: 16, type: 'sunny' },
  الدوحة: { city: 'الدوحة', temp: 29, condition: 'صافٍ ولطيف', high: 31, low: 22, humidity: 40, wind: 11, type: 'sunny' },
  عمان: { city: 'عَمّان', temp: 19, condition: 'معتدل ولطيف', high: 21, low: 12, humidity: 48, wind: 20, type: 'partly' },
  بيروت: { city: 'بيروت', temp: 22, condition: 'نسيم عليل', high: 23, low: 17, humidity: 62, wind: 14, type: 'sunny' },
  الرباط: { city: 'الرباط', temp: 20, condition: 'غائم ولطيف', high: 22, low: 14, humidity: 70, wind: 13, type: 'cloudy' },
};

export const WeatherApp: React.FC<WeatherAppProps> = ({
  initialCity = 'الرياض',
  hasLocationPermission,
  onRequestLocationPermission,
}) => {
  const [selectedCity, setSelectedCity] = useState(
    CITIES_DATA[initialCity] ? initialCity : 'الرياض'
  );
  const [searchTerm, setSearchTerm] = useState('');

  const weather = CITIES_DATA[selectedCity] || CITIES_DATA['الرياض'];

  const getWeatherIcon = (type: string, className = 'w-16 h-16') => {
    switch (type) {
      case 'sunny':
        return <Sun className={`${className} text-amber-400 animate-spin-slow`} />;
      case 'rainy':
        return <CloudRain className={`${className} text-blue-400`} />;
      case 'cloudy':
        return <Cloud className={`${className} text-slate-300`} />;
      default:
        return <CloudSun className={`${className} text-amber-300`} />;
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;
    const found = Object.keys(CITIES_DATA).find((c) =>
      c.includes(searchTerm.trim()) || searchTerm.trim().includes(c)
    );
    if (found) {
      setSelectedCity(found);
    }
    setSearchTerm('');
  };

  return (
    <div className="h-full bg-linear-to-b from-sky-600 via-sky-700 to-indigo-900 text-white flex flex-col p-5 overflow-y-auto">
      {/* Search Bar */}
      <form onSubmit={handleSearch} className="relative mb-5">
        <Search className="absolute right-3.5 top-3 w-4 h-4 text-white/60" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="ابحث عن مدينة (مثل دبي، القاهرة)..."
          className="w-full pr-10 pl-4 py-2.5 rounded-2xl bg-white/15 backdrop-blur-md placeholder-white/50 text-white text-sm outline-hidden border border-white/20 focus:border-white/50"
        />
      </form>

      {/* Location header & Permission banner */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-1.5 text-white/90">
          <MapPin className="w-5 h-5 text-amber-300" />
          <h2 className="text-2xl font-bold">{weather.city}</h2>
        </div>
        {!hasLocationPermission && (
          <button
            onClick={onRequestLocationPermission}
            className="text-xs bg-white/20 hover:bg-white/30 px-2.5 py-1 rounded-full border border-white/30 backdrop-blur-xs transition-colors"
          >
            تحديد موقعي
          </button>
        )}
      </div>

      {/* Main Temp Card */}
      <div className="flex flex-col items-center justify-center my-4 py-4 rounded-3xl bg-white/10 backdrop-blur-md border border-white/20 shadow-lg">
        {getWeatherIcon(weather.type, 'w-20 h-20 mb-2')}
        <div className="text-6xl font-black tracking-tight">{weather.temp}°</div>
        <div className="text-lg font-medium text-white/90 mt-1">{weather.condition}</div>
        <div className="text-xs text-white/70 mt-1 flex gap-3">
          <span>العظمى: {weather.high}°</span>
          <span>•</span>
          <span>الصغرى: {weather.low}°</span>
        </div>
      </div>

      {/* Details Row */}
      <div className="grid grid-cols-2 gap-3 my-2">
        <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-3">
          <Droplets className="w-6 h-6 text-cyan-300" />
          <div>
            <div className="text-xs text-white/70">الرطوبة</div>
            <div className="text-lg font-bold">{weather.humidity}%</div>
          </div>
        </div>
        <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-3">
          <Wind className="w-6 h-6 text-teal-300" />
          <div>
            <div className="text-xs text-white/70">الرياح</div>
            <div className="text-lg font-bold">{weather.wind} كم/س</div>
          </div>
        </div>
      </div>

      {/* Quick City Chips */}
      <div className="mt-4">
        <div className="text-xs text-white/70 mb-2 font-medium">مدن سريعة:</div>
        <div className="flex gap-2 flex-wrap">
          {Object.keys(CITIES_DATA).slice(0, 5).map((city) => (
            <button
              key={city}
              onClick={() => setSelectedCity(city)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                selectedCity === city
                  ? 'bg-amber-400 text-slate-900 font-bold shadow-md'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
            >
              {city}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
