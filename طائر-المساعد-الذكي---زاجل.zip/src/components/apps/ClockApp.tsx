import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Bell, Timer, Clock as ClockIcon } from 'lucide-react';
import { playAlarmChime } from '../../utils/audio';

interface ClockAppProps {
  initialTimerSeconds?: number;
}

export const ClockApp: React.FC<ClockAppProps> = ({ initialTimerSeconds }) => {
  const [activeTab, setActiveTab] = useState<'clock' | 'timer' | 'alarm'>('timer');

  // Timer State
  const [timerDuration, setTimerDuration] = useState(initialTimerSeconds || 60);
  const [timerRemaining, setTimerRemaining] = useState(initialTimerSeconds || 60);
  const [timerRunning, setTimerRunning] = useState(false);

  // Alarms State
  const [alarms, setAlarms] = useState([
    { id: '1', time: '06:00', label: 'صلاة الفجر والاستيقاظ', enabled: true },
    { id: '2', time: '08:30', label: 'بدء العمل والمهام', enabled: true },
    { id: '3', time: '13:00', label: 'استراحة الغداء', enabled: false },
  ]);

  useEffect(() => {
    if (initialTimerSeconds && initialTimerSeconds > 0) {
      setActiveTab('timer');
      setTimerDuration(initialTimerSeconds);
      setTimerRemaining(initialTimerSeconds);
      setTimerRunning(true);
    }
  }, [initialTimerSeconds]);

  useEffect(() => {
    let interval: any = null;
    if (timerRunning && timerRemaining > 0) {
      interval = setInterval(() => {
        setTimerRemaining((prev) => {
          if (prev <= 1) {
            playAlarmChime();
            setTimerRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timerRunning, timerRemaining]);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const toggleAlarm = (id: string) => {
    setAlarms((prev) =>
      prev.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a))
    );
  };

  return (
    <div className="h-full bg-slate-950 text-white flex flex-col justify-between p-5 select-none">
      {/* Top Tabs */}
      <div className="flex bg-slate-900 p-1 rounded-2xl border border-slate-800">
        <button
          onClick={() => setActiveTab('timer')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'timer' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400'
          }`}
        >
          <Timer className="w-4 h-4" />
          <span>المؤقت</span>
        </button>
        <button
          onClick={() => setActiveTab('alarm')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'alarm' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400'
          }`}
        >
          <Bell className="w-4 h-4" />
          <span>المنبهات</span>
        </button>
        <button
          onClick={() => setActiveTab('clock')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'clock' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400'
          }`}
        >
          <ClockIcon className="w-4 h-4" />
          <span>الساعة</span>
        </button>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 flex flex-col justify-center my-4 overflow-y-auto">
        {activeTab === 'timer' && (
          <div className="flex flex-col items-center">
            {/* Circular Timer Display */}
            <div className="relative w-56 h-56 rounded-full border-4 border-slate-800 flex items-center justify-center bg-slate-900/60 shadow-2xl">
              <div className="text-5xl font-mono font-light tracking-wider text-amber-400">
                {formatTime(timerRemaining)}
              </div>
              {timerRemaining === 0 && (
                <div className="absolute -top-3 px-3 py-1 bg-rose-500 text-white text-xs font-bold rounded-full animate-bounce">
                  انتهى الوقت!
                </div>
              )}
            </div>

            {/* Quick preset buttons */}
            <div className="flex gap-2 mt-6">
              {[60, 300, 600, 900].map((s) => (
                <button
                  key={s}
                  onClick={() => {
                    setTimerDuration(s);
                    setTimerRemaining(s);
                    setTimerRunning(false);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300 hover:bg-slate-700 active:scale-95 transition-all"
                >
                  {s / 60} د
                </button>
              ))}
            </div>

            {/* Play / Pause / Reset Controls */}
            <div className="flex items-center gap-6 mt-8">
              <button
                onClick={() => {
                  setTimerRemaining(timerDuration);
                  setTimerRunning(false);
                }}
                className="w-12 h-12 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center active:scale-90 hover:bg-slate-700 transition-all shadow-md"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
              <button
                onClick={() => setTimerRunning(!timerRunning)}
                className="w-16 h-16 rounded-full bg-linear-to-tr from-amber-500 to-amber-400 text-slate-950 flex items-center justify-center active:scale-90 shadow-xl shadow-amber-500/20 font-bold transition-transform"
              >
                {timerRunning ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 mr-0.5" />}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'alarm' && (
          <div className="space-y-3 px-1">
            <h3 className="text-sm font-bold text-slate-400 mb-2">منبهاتك النشطة</h3>
            {alarms.map((alarm) => (
              <div
                key={alarm.id}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between"
              >
                <div>
                  <div className="text-3xl font-light font-mono text-slate-100">{alarm.time}</div>
                  <div className="text-xs text-slate-400 mt-1">{alarm.label}</div>
                </div>
                <button
                  onClick={() => toggleAlarm(alarm.id)}
                  className={`w-12 h-7 rounded-full p-1 transition-colors ${
                    alarm.enabled ? 'bg-amber-500' : 'bg-slate-700'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      alarm.enabled ? 'translate-x-0' : '-translate-x-5'
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'clock' && (
          <div className="space-y-4 px-2 text-center">
            <div className="py-6">
              <div className="text-xs text-amber-400 font-bold">توقيت مكة المكرمة / الرياض</div>
              <div className="text-5xl font-mono font-bold text-white mt-2">
                {new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
              </div>
              <div className="text-xs text-slate-400 mt-1">GMT +3</div>
            </div>
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center text-sm">
              <span className="text-slate-300">القاهرة</span>
              <span className="font-mono text-slate-200">
                {new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center text-sm">
              <span className="text-slate-300">دبي / أبوظبي</span>
              <span className="font-mono text-slate-200">
                {new Date().toLocaleTimeString('ar-AE', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
