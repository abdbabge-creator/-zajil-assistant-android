import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, ShieldAlert, CheckCircle2, Image as ImageIcon } from 'lucide-react';
import { playCameraShutter } from '../../utils/audio';

interface CameraAppProps {
  hasPermission: boolean;
  onRequestPermission: () => Promise<boolean>;
  onPhotoTaken?: (dataUrl: string) => void;
  onOpenGallery?: () => void;
}

export const CameraApp: React.FC<CameraAppProps> = ({
  hasPermission,
  onRequestPermission,
  onPhotoTaken,
  onOpenGallery,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [capturedThumb, setCapturedThumb] = useState<string | null>(null);
  const [flashAnimation, setFlashAnimation] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let activeStream: MediaStream | null = null;

    if (hasPermission) {
      setLoading(true);
      navigator.mediaDevices
        ?.getUserMedia({
          video: { facingMode },
          audio: false,
        })
        .then((s) => {
          activeStream = s;
          setStream(s);
          if (videoRef.current) {
            videoRef.current.srcObject = s;
          }
          setLoading(false);
        })
        .catch((err) => {
          console.warn('Camera stream error:', err);
          setLoading(false);
        });
    }

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach((t) => t.stop());
      }
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [hasPermission, facingMode]);

  const handleCapture = () => {
    playCameraShutter();
    setFlashAnimation(true);
    setTimeout(() => setFlashAnimation(false), 200);

    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setCapturedThumb(dataUrl);
        onPhotoTaken?.(dataUrl);
      }
    }
  };

  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  if (!hasPermission) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-6 text-center bg-slate-900 text-white">
        <div className="w-16 h-16 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mb-4">
          <ShieldAlert className="w-9 h-9" />
        </div>
        <h3 className="text-xl font-bold mb-2">إذن الكاميرا مطلوب</h3>
        <p className="text-sm text-slate-300 max-w-xs mb-6 leading-relaxed">
          يحتاج المساعد إلى إذن الوصول إلى كاميرا هاتفك ليتمكن من التقاط الصور وعرض البث المباشر.
        </p>
        <button
          onClick={onRequestPermission}
          className="px-6 py-3 rounded-full bg-linear-to-r from-emerald-500 to-teal-600 text-white font-bold shadow-lg shadow-emerald-500/30 hover:brightness-110 active:scale-95 transition-all flex items-center gap-2"
        >
          <CheckCircle2 className="w-5 h-5" />
          <span>منح إذن الكاميرا الآن</span>
        </button>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full bg-black flex flex-col justify-between overflow-hidden">
      {/* Flash Effect on capture */}
      {flashAnimation && <div className="absolute inset-0 bg-white z-50 pointer-events-none transition-opacity" />}

      {/* Top Header controls */}
      <div className="relative z-10 p-4 flex justify-between items-center text-white/90 bg-linear-to-b from-black/70 to-transparent">
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-md">
          فيديو مباشر
        </span>
        <button
          onClick={toggleFacingMode}
          className="p-2.5 rounded-full bg-white/20 backdrop-blur-md hover:bg-white/30 active:scale-90 transition-all text-white"
          title="تبديل الكاميرا"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Video Viewport */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {loading ? (
          <div className="text-slate-400 text-sm animate-pulse">جاري تشغيل الكاميرا...</div>
        ) : (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
          />
        )}
      </div>

      {/* Bottom Controls */}
      <div className="relative z-10 p-6 bg-linear-to-t from-black/85 via-black/50 to-transparent flex items-center justify-around">
        {/* Gallery Thumbnail Preview */}
        <button
          onClick={onOpenGallery}
          className="w-12 h-12 rounded-xl border-2 border-white/60 overflow-hidden bg-slate-800 flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-md"
        >
          {capturedThumb ? (
            <img src={capturedThumb} alt="المعرض" className="w-full h-full object-cover" />
          ) : (
            <ImageIcon className="w-6 h-6 text-slate-400" />
          )}
        </button>

        {/* Big Shutter Button */}
        <button
          onClick={handleCapture}
          className="w-18 h-18 rounded-full border-4 border-white p-1 hover:scale-105 active:scale-90 transition-all shadow-xl flex items-center justify-center"
        >
          <div className="w-full h-full rounded-full bg-white active:bg-slate-300 transition-colors" />
        </button>

        {/* Placeholder spacer */}
        <div className="w-12 h-12" />
      </div>
    </div>
  );
};
