/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  Mic,
  Volume2,
  Sparkles,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  Info,
  Maximize2,
  Minimize2,
  Wand2,
  Layers,
  Zap,
} from 'lucide-react';
import {
  AppId,
  BirdEmotion,
  PermissionsState,
  ProcessResponse,
  CharacterId,
  VoiceGender,
  AndroidSystemState,
} from './types';
import { PhoneScreen } from './components/PhoneScreen';
import { CHARACTER_PROFILES } from './components/characters/characterProfiles';
import { speakArabicText, stopSpeaking, playChirp, playRobotBeep, playHumanChime } from './utils/audio';

export default function App() {
  // Character Customization State (Persistent)
  const [selectedCharacter, setSelectedCharacter] = useState<CharacterId>(() => {
    try {
      const saved = localStorage.getItem('zajil_character') as CharacterId;
      if (saved && ['male_bird', 'female_bird', 'smart_robot', 'cartoon_human'].includes(saved)) {
        return saved;
      }
    } catch (e) {}
    return 'male_bird';
  });

  const [voiceGender, setVoiceGender] = useState<VoiceGender>(() => {
    try {
      const saved = localStorage.getItem('zajil_voice_gender') as VoiceGender;
      if (saved === 'male' || saved === 'female') return saved;
    } catch (e) {}
    return 'male';
  });

  // Android Floating Overlay & Accessibility System State (Persistent)
  const [systemState, setSystemState] = useState<AndroidSystemState>(() => {
    try {
      const saved = localStorage.getItem('zajil_android_system');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      floatingOverlayEnabled: true,
      overlayPermissionGranted: true,
      accessibilityServiceEnabled: true,
      flightAnimationEnabled: true,
      snapToEdges: true,
    };
  });

  // Animation and Voice Output States
  const [birdEmotion, setBirdEmotion] = useState<BirdEmotion>('idle');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [beakOpen, setBeakOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // Active Simulated Android App
  const [activeApp, setActiveApp] = useState<AppId | null>(null);
  const [appPayload, setAppPayload] = useState<any>(null);

  // Flashlight state
  const [flashlightOn, setFlashlightOn] = useState(false);

  // Photos captured by Camera
  const [photos, setPhotos] = useState<string[]>([]);

  // Permissions State
  const [permissions, setPermissions] = useState<PermissionsState>(() => {
    try {
      const saved = localStorage.getItem('zajil_permissions');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      microphone: false,
      camera: false,
      geolocation: false,
      notifications: false,
    };
  });

  // Assistant Voice Tuning
  const [voicePitch, setVoicePitch] = useState<number>(() => {
    return CHARACTER_PROFILES[selectedCharacter]?.defaultPitch || 1.05;
  });
  const [voiceRate, setVoiceRate] = useState<number>(() => {
    return CHARACTER_PROFILES[selectedCharacter]?.defaultRate || 1.0;
  });

  // View mode (phone frame vs expanded)
  const [fullPhoneMode, setFullPhoneMode] = useState(false);

  // Speech Recognition Reference
  const recognitionRef = useRef<any>(null);

  const currentProfile = CHARACTER_PROFILES[selectedCharacter] || CHARACTER_PROFILES.male_bird;

  // Save Character, Voice, Permissions & System state to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('zajil_character', selectedCharacter);
      localStorage.setItem('zajil_voice_gender', voiceGender);
      localStorage.setItem('zajil_permissions', JSON.stringify(permissions));
      localStorage.setItem('zajil_android_system', JSON.stringify(systemState));
    } catch (e) {}
  }, [selectedCharacter, voiceGender, permissions, systemState]);

  // Request genuine browser permissions
  const handleRequestPermission = async (name: keyof PermissionsState): Promise<boolean> => {
    try {
      if (name === 'microphone') {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
        setPermissions((p) => ({ ...p, microphone: true }));
        playChirp('success');
        return true;
      }

      if (name === 'camera') {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach((t) => t.stop());
        setPermissions((p) => ({ ...p, camera: true }));
        playChirp('success');
        return true;
      }

      if (name === 'geolocation') {
        return new Promise((resolve) => {
          if (!navigator.geolocation) {
            resolve(false);
            return;
          }
          navigator.geolocation.getCurrentPosition(
            () => {
              setPermissions((p) => ({ ...p, geolocation: true }));
              playChirp('success');
              resolve(true);
            },
            () => resolve(false)
          );
        });
      }

      if (name === 'notifications') {
        if ('Notification' in window) {
          const res = await Notification.requestPermission();
          const granted = res === 'granted';
          setPermissions((p) => ({ ...p, notifications: granted }));
          if (granted) playChirp('success');
          return granted;
        }
      }
    } catch (err) {
      console.warn('Permission request error:', err);
    }
    return false;
  };

  // Initialize Speech Recognition for Arabic
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.lang = 'ar-SA';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      recognition.continuous = false;

      recognition.onstart = () => {
        setIsListening(true);
        setBirdEmotion('listening');
        playChirp('question');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          handleSendCommand(transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        setBirdEmotion('idle');
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
      stopSpeaking();
    };
  }, []);

  const toggleListening = async () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      setBirdEmotion('idle');
      return;
    }

    // Stop speaking if assistant is talking
    stopSpeaking();
    setIsSpeaking(false);

    // Request microphone permission if not yet granted
    if (!permissions.microphone) {
      const granted = await handleRequestPermission('microphone');
      if (!granted) {
        handlePlaySpokenResponse(
          'أحتاج إلى إذن استخدام الميكروفون أولاً لأتمكن من الاستماع إلى صوتك الجميل!',
          'curious'
        );
        return;
      }
    }

    try {
      recognitionRef.current?.start();
    } catch (e) {
      console.warn('Failed to start speech recognition:', e);
      setIsListening(false);
    }
  };

  // Process User Command with Server-side Gemini NLU
  const handleSendCommand = async (commandText: string) => {
    setIsListening(false);
    setBirdEmotion('thinking');

    try {
      const res = await fetch('/api/assistant/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command: commandText,
          currentContext: { activeApp, flashlightOn, selectedCharacter, voiceGender },
          permissions,
        }),
      });

      if (!res.ok) {
        throw new Error('Server error');
      }

      const data: ProcessResponse = await res.json();

      // Trigger Confetti if celebration
      if (data.birdEmotion === 'cheering' || data.birdEmotion === 'happy') {
        confetti({
          particleCount: 35,
          spread: 60,
          origin: { y: 0.6 },
        });
      }

      // Handle App Actions
      if (data.action) {
        executeAction(data.action);
      }

      // Play Spoken Voice (Strictly Audio, NOT displayed as text on screen)
      await handlePlaySpokenResponse(data.spokenReply, data.birdEmotion);
    } catch (err) {
      console.error('Error handling command:', err);
      handlePlaySpokenResponse(
        'عذراً، حدث خطأ بسيط في الاتصال. هل يمكنك إعادة المحاولة؟',
        'surprised'
      );
    }
  };

  // Execute App Actions based on Assistant intent
  const executeAction = (action: NonNullable<ProcessResponse['action']>) => {
    switch (action.type) {
      case 'open_app':
        if (action.appId) {
          if (action.requiresPermission && !permissions[action.requiresPermission]) {
            handleRequestPermission(action.requiresPermission);
          }
          setActiveApp(action.appId);
          setAppPayload(action.payload);
        }
        break;

      case 'calculate':
        setActiveApp('calculator');
        setAppPayload(action.payload);
        break;

      case 'weather_query':
        setActiveApp('weather');
        setAppPayload(action.payload);
        break;

      case 'set_timer':
        setActiveApp('clock');
        setAppPayload(action.payload);
        break;

      case 'play_music':
        setActiveApp('music');
        break;

      case 'add_note':
        setActiveApp('notes');
        setAppPayload(action.payload);
        break;

      case 'make_call':
        setActiveApp('phone');
        setAppPayload(action.payload);
        break;

      case 'send_message':
        setActiveApp('messages');
        setAppPayload(action.payload);
        break;

      case 'toggle_flashlight':
        setFlashlightOn((prev) => !prev);
        break;

      case 'close_app':
        setActiveApp(null);
        break;

      case 'request_permission':
        if (action.requiresPermission) {
          handleRequestPermission(action.requiresPermission);
        }
        break;

      default:
        break;
    }
  };

  // Play Spoken Arabic Audio with Mouth / Beak / LED flap synchronization
  const handlePlaySpokenResponse = async (
    textToSpeak: string,
    emotion: BirdEmotion = 'speaking',
    overrideGender?: VoiceGender
  ) => {
    const currentGender = overrideGender || voiceGender;
    setBirdEmotion(emotion);

    let audioBase64: string | undefined;

    // Call server TTS endpoint
    try {
      const ttsRes = await fetch('/api/assistant/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToSpeak, gender: currentGender }),
      });
      if (ttsRes.ok) {
        const ttsData = await ttsRes.json();
        if (ttsData.audioBase64) {
          audioBase64 = ttsData.audioBase64;
        }
      }
    } catch (e) {
      console.warn('TTS request error, using browser Web Speech:', e);
    }

    // Speak using audio player or Web Speech synthesis
    speakArabicText({
      text: textToSpeak,
      audioBase64,
      gender: currentGender,
      voicePitch,
      voiceRate,
      onStart: () => {
        setIsSpeaking(true);
      },
      onEnd: () => {
        setIsSpeaking(false);
        setBeakOpen(false);
        setBirdEmotion('idle');
      },
      onBeakTick: (isOpen) => {
        setBeakOpen(isOpen);
      },
    });
  };

  const handlePetCharacter = () => {
    setBirdEmotion('happy');
    confetti({
      particleCount: 20,
      spread: 45,
      origin: { y: 0.5 },
    });
    setTimeout(() => {
      setBirdEmotion('idle');
    }, 2000);
  };

  const handlePhotoTaken = (dataUrl: string) => {
    setPhotos((prev) => [dataUrl, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-2 sm:p-5 relative overflow-x-hidden selection:bg-cyan-500 selection:text-white">
      {/* Ambient background glow spheres */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container Layout */}
      <div className="w-full max-w-5xl flex flex-col lg:flex-row items-center justify-center gap-7 relative z-10">
        {/* Desktop Left Info & Character Showcase Panel */}
        {!fullPhoneMode && (
          <div className="hidden lg:flex flex-col max-w-sm p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800 shadow-2xl text-right">
            {/* Active Character Header */}
            <div className="flex items-center gap-3 mb-3">
              <div
                className={`w-12 h-12 rounded-2xl ${currentProfile.avatarBg} flex items-center justify-center text-2xl shadow-lg shadow-cyan-500/20`}
              >
                {selectedCharacter === 'male_bird'
                  ? '🐦'
                  : selectedCharacter === 'female_bird'
                  ? '🌸'
                  : selectedCharacter === 'smart_robot'
                  ? '🤖'
                  : '🧑'}
              </div>
              <div>
                <h1 className="text-xl font-black text-white">{currentProfile.name}</h1>
                <p className="text-xs text-cyan-400 font-semibold">{currentProfile.title}</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              مساعد عائم على نظام Android مع حركات طيران وسحب باللمس، وتكامل مع إمكانية الوصول
              لتنفيذ النقرات الحقيقية على الشاشة مع كود Kotlin أصلي جاهز للتصدير!
            </p>

            {/* Android Overlay Status Card */}
            <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 mb-4 text-xs">
              <div className="flex items-center justify-between font-bold text-emerald-300 mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>نظام الطائر العائم (Android Overlay)</span>
                </span>
                <span className="text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded-md border border-emerald-500/40">
                  نشط
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                اسحب الطائر بإصبعك/الماوس في أي مكان، أو اطلب فتح تطبيق ليطير وينقر عليه بمنقاره!
              </p>
              <button
                onClick={() => setActiveApp('android_service')}
                className="mt-2 w-full py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold border border-emerald-500/40 transition-colors flex items-center justify-center gap-1 text-[11px]"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>إدارة خدمات أندرويد وكود Kotlin</span>
              </button>
            </div>

            {/* 4 Characters Quick Selector */}
            <div className="mb-4">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>الشخصية العائمة الحالية:</span>
                <button
                  onClick={() => setActiveApp('customizer')}
                  className="text-cyan-400 font-normal hover:underline flex items-center gap-0.5 text-[10px]"
                >
                  <Wand2 className="w-3 h-3" />
                  <span>تخصيص كامل</span>
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {Object.values(CHARACTER_PROFILES).map((char) => (
                  <button
                    key={char.id}
                    onClick={() => {
                      setSelectedCharacter(char.id as CharacterId);
                      setVoiceGender(char.gender);
                      setVoicePitch(char.defaultPitch);
                      setVoiceRate(char.defaultRate);
                      if (char.id === 'smart_robot') playRobotBeep('success');
                      else if (char.id === 'cartoon_human') playHumanChime('success');
                      else playChirp('success');
                    }}
                    className={`p-2 rounded-xl border text-right transition-all flex items-center gap-2 ${
                      selectedCharacter === char.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-white font-bold shadow-md'
                        : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-base">
                      {char.id === 'male_bird'
                        ? '🐦'
                        : char.id === 'female_bird'
                        ? '🌸'
                        : char.id === 'smart_robot'
                        ? '🤖'
                        : '🧑'}
                    </span>
                    <span className="text-xs">{char.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Voice Examples List */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                جرب الطيران والنقر بالأوامر الصوتية:
              </h3>
              <div className="space-y-1 text-xs">
                {[
                  '«افتح الكاميرا» (يطير وينقر عليها)',
                  '«احسب 120 في 5»',
                  '«شغل لي بعض الموسيقى»',
                  '«افتح خدمات أندرويد»',
                  '«ما هي أحوال الطقس في الرياض؟»',
                  '«اضبط مؤقت لمدة دقيقة»',
                ].map((sample, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendCommand(sample.replace(/[«»]/g, ''))}
                    className="w-full text-right p-1.5 rounded-lg bg-slate-800/40 hover:bg-slate-800 hover:text-cyan-300 text-slate-300 transition-colors flex items-center justify-between"
                  >
                    <span>{sample}</span>
                    <Zap className="w-3 h-3 text-amber-400 opacity-60" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ANDROID SMARTPHONE DEVICE */}
        <div className="flex flex-col items-center">
          <PhoneScreen
            selectedCharacter={selectedCharacter}
            onSelectCharacter={setSelectedCharacter}
            voiceGender={voiceGender}
            onSelectVoiceGender={setVoiceGender}
            onTestVoice={(greeting, gender) => handlePlaySpokenResponse(greeting, 'speaking', gender)}
            birdEmotion={birdEmotion}
            isSpeaking={isSpeaking}
            beakOpen={beakOpen}
            isListening={isListening}
            onToggleListening={toggleListening}
            onSendCommand={handleSendCommand}
            onPetBird={handlePetCharacter}
            systemState={systemState}
            onUpdateSystemState={(partial) =>
              setSystemState((prev) => ({ ...prev, ...partial }))
            }
            activeApp={activeApp}
            onOpenApp={(app) => {
              setActiveApp(app);
              playChirp('cheerful');
            }}
            onCloseApp={() => {
              setActiveApp(null);
              playChirp('cheerful');
            }}
            appPayload={appPayload}
            permissions={permissions}
            onRequestPermission={handleRequestPermission}
            voicePitch={voicePitch}
            setVoicePitch={setVoicePitch}
            voiceRate={voiceRate}
            setVoiceRate={setVoiceRate}
            photos={photos}
            onPhotoTaken={handlePhotoTaken}
            flashlightOn={flashlightOn}
            onToggleFlashlight={() => setFlashlightOn(!flashlightOn)}
          />

          {/* Toggle Fullscreen / Compact frame button (for desktop comfort) */}
          <button
            onClick={() => setFullPhoneMode(!fullPhoneMode)}
            className="mt-3 hidden lg:flex items-center gap-1.5 text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 transition-colors"
          >
            {fullPhoneMode ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span>{fullPhoneMode ? 'إظهار اللوحة الجانبية' : 'شاشة الهاتف فقط'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
