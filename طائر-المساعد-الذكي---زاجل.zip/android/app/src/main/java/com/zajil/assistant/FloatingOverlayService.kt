package com.zajil.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.FrameLayout
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator

/**
 * FloatingOverlayService:
 * Implements the native Android Floating Window Overlay that renders the animated
 * bird character on top of all other third-party apps and the Android Home launcher.
 */
class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: FrameLayout
    private lateinit var birdAvatar: ImageView
    private lateinit var layoutParams: WindowManager.LayoutParams

    private val CHANNEL_ID = "ZajilFloatingServiceChannel"

    companion object {
        var instance: FloatingOverlayService? = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        createNotificationChannel()
        startForeground(1, createForegroundNotification())

        setupFloatingView()
    }

    private fun setupFloatingView() {
        floatingView = FrameLayout(this)
        birdAvatar = ImageView(this).apply {
            // Animated bird icon / character asset
            setImageResource(android.R.drawable.ic_dialog_info)
            layoutParams = FrameLayout.LayoutParams(180, 180)
        }
        floatingView.addView(birdAvatar)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        windowManager.addView(floatingView, layoutParams)
        attachTouchListener()
    }

    private fun attachTouchListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        floatingView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                    layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, layoutParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val diffX = Math.abs(event.rawX - initialTouchX)
                    val diffY = Math.abs(event.rawY - initialTouchY)
                    if (diffX < 10 && diffY < 10) {
                        // Single tap on bird -> Trigger Voice Listening
                        onBirdClicked()
                    } else {
                        // Snap smoothly to closest screen edge (Left / Right)
                        snapToEdge()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun snapToEdge() {
        val screenWidth = resources.displayMetrics.widthPixels
        val targetX = if (layoutParams.x < screenWidth / 2) 20 else screenWidth - floatingView.width - 20
        val animator = ValueAnimator.ofInt(layoutParams.x, targetX).apply {
            duration = 250
            interpolator = DecelerateInterpolator()
            addUpdateListener { animation ->
                layoutParams.x = animation.animatedValue as Int
                windowManager.updateViewLayout(floatingView, layoutParams)
            }
        }
        animator.start()
    }

    /**
     * Fly smoothly towards a target screen position (targetX, targetY),
     * peck the app icon, and trigger Accessibility click!
     */
    fun flyToTargetAndClick(targetX: Int, targetY: Int, onComplete: () => Unit) {
        val startX = layoutParams.x
        val startY = layoutParams.y

        val flightAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 600
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                val fraction = anim.animatedFraction
                layoutParams.x = (startX + (targetX - startX) * fraction).toInt()
                layoutParams.y = (startY + (targetY - startY) * fraction).toInt()
                windowManager.updateViewLayout(floatingView, layoutParams)
            }
        }

        flightAnim.start()
        flightAnim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                // Perform Pecking gesture and execute accessibility click
                ZajilAccessibilityService.instance?.clickAtCoordinates(targetX.toFloat(), targetY.toFloat()) {
                    onComplete()
                }
            }
        })
    }

    private fun onBirdClicked() {
        // Trigger voice recognition flow
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة زاجل العائمة",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createForegroundNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("المساعد الذكي زاجل يعمل في الخلفية")
            .setContentText("الطائر العائم نشط ومستعد للأوامر الصوتية فوق جميع التطبيقات")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
        instance = null
    }
}
